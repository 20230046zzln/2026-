#include "sm3.h"
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
 * SM3 初始值
 *
 * 八个32位整数
 * 最后拼成256 bit输出
 */
static const uint32_t IV[8] =
{
    0x7380166f,
    0x4914b2b9,
    0x172442d7,
    0xda8a0600,
    0xa96f30bc,
    0x163138aa,
    0xe38dee4d,
    0xb0fb0e4e
};



/*
 * 循环左移
 *
 * 例如:
 *
 * 10110001
 *
 * 左移3位:
 *
 * 10001101
 *
 */
static uint32_t ROTL(
    uint32_t x,
    int n
)
{
    return (x << n) | (x >> (32 - n));
}



/*
 * SM3置换函数P0
 */
static uint32_t P0(uint32_t x)
{
    return x ^ ROTL(x,9) ^ ROTL(x,17);
}



/*
 * SM3置换函数P1
 */
static uint32_t P1(uint32_t x)
{
    return x ^ ROTL(x,15) ^ ROTL(x,23);
}


/*
 * SM3消息填充
 *
 * 输入:
 * message 原消息
 * len     原长度(byte)
 *
 * 输出:
 * new_len 填充后的长度(byte)
 */
static uint8_t* padding(
    const uint8_t *message,
    uint64_t len,
    uint64_t *new_len
)
{

    /*
     * 原长度(bit)
     */
    uint64_t bit_len = len * 8;


    /*
     * 计算填充后长度
     *
     * 必须满足:
     *
     * new_len % 64 == 0
     */
    uint64_t total_len = len + 1 + 8;


    while(total_len % 64 != 0)
    {
        total_len++;
    }


    uint8_t *msg =
        (uint8_t*)malloc(total_len);


    /*
     * 复制原消息
     */
    memcpy(
        msg,
        message,
        len
    );


    /*
     * 添加0x80
     */
    msg[len]=0x80;



    /*
     * 补0
     */
    for(
        uint64_t i=len+1;
        i<total_len-8;
        i++
    )
    {
        msg[i]=0;
    }



    /*
     * 添加长度
     *
     * SM3使用大端
     */
    for(int i=0;i<8;i++)
    {
        msg[total_len-1-i]
            =
        (bit_len>>(8*i)) & 0xff;
    }


    *new_len=total_len;


    return msg;
}

/*
 * SM3消息扩展
 *
 * 输入:
 * block: 64字节消息块
 *
 * 输出:
 * W[0~67]
 */
static void expand(
    const uint8_t block[64],
    uint32_t W[68]
)
{

    /*
     * 第一步:
     *
     * 将64字节转换成16个32位整数
     *
     * SM3使用大端
     */


    for(int i=0;i<16;i++)
    {

        W[i] =
            ((uint32_t)block[i*4] << 24)
          | ((uint32_t)block[i*4+1] << 16)
          | ((uint32_t)block[i*4+2] << 8)
          | ((uint32_t)block[i*4+3]);

    }



    /*
     * 第二步:
     *
     * 计算W[16]-W[67]
     */

    for(int j=16;j<68;j++)
    {

        W[j] =
            P1(
                W[j-16]
                ^
                W[j-9]
                ^
                ROTL(W[j-3],15)
            )
            ^
            ROTL(W[j-13],7)
            ^
            W[j-6];

    }

}

static uint32_t FF(
    uint32_t x,
    uint32_t y,
    uint32_t z,
    int j
)
{
    if(j < 16)
    {
        return x ^ y ^ z;
    }
    else
    {
        return (x & y)
             | (x & z)
             | (y & z);
    }
}

static uint32_t GG(
    uint32_t x,
    uint32_t y,
    uint32_t z,
    int j
)
{
    if(j < 16)
    {
        return x ^ y ^ z;
    }
    else
    {
        return (x & y)
             | ((~x) & z);
    }
}

static uint32_t T(int j)
{
    if(j < 16)
    {
        return 0x79cc4519;
    }
    else
    {
        return 0x7a879d8a;
    }
}

static void compress(
    uint32_t state[8],
    uint32_t W[68]
)
{

    uint32_t A = state[0];
    uint32_t B = state[1];
    uint32_t C = state[2];
    uint32_t D = state[3];
    uint32_t E = state[4];
    uint32_t F = state[5];
    uint32_t G = state[6];
    uint32_t H = state[7];


    for(int j=0;j<64;j++)
    {

        uint32_t SS1 =
            ROTL(
                ROTL(A,12)
                +
                E
                +
                ROTL(T(j),j),
                7
            );


        uint32_t SS2 =
            SS1 ^ ROTL(A,12);



        uint32_t TT1 =
            FF(A,B,C,j)
            +
            D
            +
            SS2
            +
            (W[j]^W[j+4]);



        uint32_t TT2 =
            GG(E,F,G,j)
            +
            H
            +
            SS1
            +
            W[j];



        D=C;

        C=ROTL(B,9);

        B=A;

        A=TT1;


        H=G;

        G=ROTL(F,19);

        F=E;

        E=P0(TT2);

    }



    /*
     * 与旧状态异或
     */

    state[0]^=A;
    state[1]^=B;
    state[2]^=C;
    state[3]^=D;
    state[4]^=E;
    state[5]^=F;
    state[6]^=G;
    state[7]^=H;

}

void sm3(
    const uint8_t *message,
    uint64_t len,
    uint8_t digest[32]
)
{

    /*
     * 1. 消息填充
     */

    uint64_t padded_len;


    uint8_t *padded =
        padding(
            message,
            len,
            &padded_len
        );



    /*
     * 2. 初始化状态
     */

    uint32_t state[8];


    for(int i=0;i<8;i++)
    {
        state[i]=IV[i];
    }



    /*
     * 3. 对每个512bit消息块进行压缩
     */

    uint32_t W[68];


    for(uint64_t i=0;i<padded_len;i+=64)
    {

        /*
         * 消息扩展
         */

        expand(
            padded+i,
            W
        );


        /*
         * 压缩函数
         */

        compress(
            state,
            W
        );

    }



    /*
     * 4. 输出256bit结果
     *
     * state:
     *
     * state[0]
     * state[1]
     * ...
     * state[7]
     *
     * 每个32bit
     *
     * 共256bit
     */


    for(int i=0;i<8;i++)
    {

        digest[i*4]
            =
            (state[i] >> 24) & 0xff;


        digest[i*4+1]
            =
            (state[i] >> 16) & 0xff;


        digest[i*4+2]
            =
            (state[i] >> 8) & 0xff;


        digest[i*4+3]
            =
            state[i] & 0xff;

    }



    /*
     * 5. 释放padding申请的内存
     */

    free(padded);

}
