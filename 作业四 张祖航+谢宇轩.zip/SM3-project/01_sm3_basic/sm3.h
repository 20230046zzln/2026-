#ifndef SM3_H
#define SM3_H

#include <stdint.h>

void sm3(
    const uint8_t *message,
    uint64_t len,
    uint8_t digest[32]
);

#endif
