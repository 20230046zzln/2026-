#include "sm3.h"

#include <stdio.h>
#include <stdint.h>
#include <time.h>


#define TEST_NUM 1000000



int main()
{

    uint8_t msg[64];

    uint8_t digest[32];


    /*
     * 一个完整block
     */
    for(int i=0;i<64;i++)
    {
        msg[i]=i;
    }



    struct timespec start,end;


    clock_gettime(
        CLOCK_MONOTONIC,
        &start
    );



    for(int i=0;i<TEST_NUM;i++)
    {

        sm3(
            msg,
            64,
            digest
        );

    }



    clock_gettime(
        CLOCK_MONOTONIC,
        &end
    );



    double time_used =
        (end.tv_sec-start.tv_sec)
        +
        (end.tv_nsec-start.tv_nsec)
        /
        1000000000.0;



    double data_MB =
        (double)64
        *
        TEST_NUM
        /
        1024
        /
        1024;



    printf(
        "Basic SM3 block:\n"
    );


    printf(
        "time = %.6f s\n",
        time_used
    );


    printf(
        "data = %.2f MB\n",
        data_MB
    );


    printf(
        "speed = %.2f MB/s\n",
        data_MB/time_used
    );


    return 0;

}
