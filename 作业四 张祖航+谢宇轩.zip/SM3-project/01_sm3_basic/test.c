#include "sm3.h"
#include <stdio.h>
#include <string.h>


int main()
{

    char *msg="abc";


    uint8_t digest[32];


    sm3(
        (uint8_t*)msg,
        strlen(msg),
        digest
    );



    printf("SM3 digest:\n");


    for(int i=0;i<32;i++)
    {
        printf(
            "%02x",
            digest[i]
        );
    }


    printf("\n");


    return 0;
}
