#include "sm3.h"

#include <stdio.h>
#include <string.h>
#include <time.h>


#define TEST_NUM 1000000


int main()
{

    uint8_t msg[64]={0};

    msg[0]='a';
    msg[1]='b';
    msg[2]='c';
    msg[3]=0x80;
    msg[63]=0x18;


    uint8_t digest[32];


    clock_t start,end;


    start=clock();


    for(int i=0;i<TEST_NUM;i++)
    {

        sm3(
            msg,
            3,
            digest
        );

    }


    end=clock();



    double time_used=
        (double)(end-start)
        /
        CLOCKS_PER_SEC;



    printf(
        "Basic SM3:\n"
    );


    printf(
        "time = %f s\n",
        time_used
    );


    printf(
        "speed = %.2f MB/s\n",
        (TEST_NUM*3.0/1024/1024)
        /
        time_used
    );


    return 0;

}
