#include "sm3.h"

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <time.h>


#define MSG_SIZE 8192
#define TEST_NUM 10000



int main()
{

    uint8_t msg[MSG_SIZE];

    uint8_t digest[32];


    /*
     * 构造测试消息
     */
    for(int i=0;i<MSG_SIZE;i++)
    {
        msg[i]=i&0xff;
    }



    struct timespec start,end;



    clock_gettime(
        CLOCK_MONOTONIC,
        &start
    );



    for(int i=0;i<TEST_NUM;i++)
    {

        sm3(
            msg,
            MSG_SIZE,
            digest
        );

    }



    clock_gettime(
        CLOCK_MONOTONIC,
        &end
    );



    double time_used =
        (end.tv_sec-start.tv_sec)
        +
        (end.tv_nsec-start.tv_nsec)
        /
        1000000000.0;



    double data_MB =
        (double)MSG_SIZE
        *
        TEST_NUM
        /
        1024
        /
        1024;



    printf(
        "Basic SM3 large message:\n"
    );


    printf(
        "time = %.6f s\n",
        time_used
    );


    printf(
        "data = %.2f MB\n",
        data_MB
    );


    printf(
        "speed = %.2f MB/s\n",
        data_MB/time_used
    );


    return 0;

}
