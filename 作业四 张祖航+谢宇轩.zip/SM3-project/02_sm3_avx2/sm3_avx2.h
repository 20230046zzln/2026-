#ifndef SM3_AVX2_H
#define SM3_AVX2_H


#include <stdint.h>
#include <immintrin.h>


/*
 * AVX2并行数量
 *
 * 256 bit / 32 bit = 8
 */
#define SM3_AVX2_LANES 8



/*
 * AVX2 SM3函数
 *
 * 输入:
 *
 * 8个64字节消息块
 *
 * 输出:
 *
 * 8个32字节digest
 *
 */
void sm3_avx2(
    const uint8_t msg[SM3_AVX2_LANES][64],
    uint8_t digest[SM3_AVX2_LANES][32]
);



#endif
