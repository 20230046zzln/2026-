#include "sm3_avx2.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>



/*
 * SM3初始值
 *
 * 8个32bit整数
 */
static const uint32_t IV[8] =
{
    0x7380166f,
    0x4914b2b9,
    0x172442d7,
    0xda8a0600,
    0xa96f30bc,
    0x163138aa,
    0xe38dee4d,
    0xb0fb0e4e
};




/*
 * AVX2版本循环左移
 *
 * 对8个uint32同时操作
 *
 * x:
 *
 * |x0|x1|x2|...|x7|
 *
 */
static __m256i ROTL256(
    __m256i x,
    int n
)
{

    return _mm256_or_si256(

        _mm256_slli_epi32(
            x,
            n
        ),

        _mm256_srli_epi32(
            x,
            32-n
        )

    );

}




/*
 * P0函数
 *
 * P0(X)=X^ROTL(X,9)^ROTL(X,17)
 *
 */
static __m256i P0_256(
    __m256i x
)
{

    return _mm256_xor_si256(

        x,

        _mm256_xor_si256(

            ROTL256(
                x,
                9
            ),

            ROTL256(
                x,
                17
            )

        )

    );

}





/*
 * P1函数
 *
 * P1(X)=X^ROTL(X,15)^ROTL(X,23)
 *
 */
static __m256i P1_256(
    __m256i x
)
{

    return _mm256_xor_si256(

        x,

        _mm256_xor_si256(

            ROTL256(
                x,
                15
            ),

            ROTL256(
                x,
                23
            )

        )

    );

}





/*
 * FF函数 AVX2版本
 *
 *
 * j < 16:
 *
 * X ^ Y ^ Z
 *
 *
 * j >=16:
 *
 * (X&Y)|(X&Z)|(Y&Z)
 *
 */
static __m256i FF256(
    __m256i x,
    __m256i y,
    __m256i z,
    int j
)
{

    if(j < 16)
    {

        return _mm256_xor_si256(

            _mm256_xor_si256(
                x,
                y
            ),

            z

        );

    }
    else
    {

        return _mm256_or_si256(

            _mm256_or_si256(

                _mm256_and_si256(
                    x,
                    y
                ),

                _mm256_and_si256(
                    x,
                    z
                )

            ),

            _mm256_and_si256(
                y,
                z
            )

        );

    }

}





/*
 * GG函数 AVX2版本
 *
 *
 * j <16:
 *
 * X^Y^Z
 *
 *
 * j>=16:
 *
 * (X&Y)|(~X&Z)
 *
 */
static __m256i GG256(
    __m256i x,
    __m256i y,
    __m256i z,
    int j
)
{

    if(j < 16)
    {

        return _mm256_xor_si256(

            _mm256_xor_si256(
                x,
                y
            ),

            z

        );

    }
    else
    {

        return _mm256_or_si256(

            _mm256_and_si256(
                x,
                y
            ),

            _mm256_andnot_si256(
                x,
                z
            )

        );

    }

}





/*
 * SM3轮常量T
 *
 * 由于8路SM3使用相同T
 *
 * 直接广播到8个位置
 *
 */
static __m256i T256(
    int j
)
{

    uint32_t t;


    if(j < 16)
    {
        t = 0x79cc4519;
    }
    else
    {
        t = 0x7a879d8a;
    }



    return _mm256_set1_epi32(
        t
    );

}
/*
 * AVX2消息扩展
 *
 * 输入:
 *
 * block[8][64]
 *
 * 8个512bit消息块
 *
 *
 * 输出:
 *
 * W[68]
 *
 * 每个W[j]:
 *
 * |msg0|msg1|...|msg7|
 *
 */
static void expand_avx2(
    const uint8_t block[8][64],
    __m256i W[68]
)
{

    uint32_t temp[8];


    /*
     * W0~W15
     *
     * 从消息块读取
     *
     * SM3采用大端
     */

    for(int j=0;j<16;j++)
    {


        for(int lane=0;lane<8;lane++)
        {

            temp[lane]=
                ((uint32_t)block[lane][j*4] << 24)
                |
                ((uint32_t)block[lane][j*4+1] << 16)
                |
                ((uint32_t)block[lane][j*4+2] << 8)
                |
                ((uint32_t)block[lane][j*4+3]);

        }


        W[j]=_mm256_set_epi32(

            temp[7],
            temp[6],
            temp[5],
            temp[4],

            temp[3],
            temp[2],
            temp[1],
            temp[0]

        );

    }



    /*
     * W16~W67
     *
     *
     * Wj =
     * P1(Wj-16 ^ Wj-9 ^ ROTL(Wj-3,15))
     * ^ ROTL(Wj-13,7)
     * ^ Wj-6
     *
     */

    for(int j=16;j<68;j++)
    {

        __m256i x =
            _mm256_xor_si256(

                _mm256_xor_si256(

                    W[j-16],

                    W[j-9]

                ),

                ROTL256(
                    W[j-3],
                    15
                )

            );



        W[j]=
            _mm256_xor_si256(

                _mm256_xor_si256(

                    P1_256(x),

                    ROTL256(
                        W[j-13],
                        7
                    )

                ),

                W[j-6]

            );

    }

}






/*
 * AVX2 SM3压缩函数
 *
 * 一次处理8个消息
 */
static void compress_avx2(
    __m256i state[8],
    __m256i W[68]
)
{


    __m256i A=state[0];
    __m256i B=state[1];
    __m256i C=state[2];
    __m256i D=state[3];

    __m256i E=state[4];
    __m256i F=state[5];
    __m256i G=state[6];
    __m256i H=state[7];



    for(int j=0;j<64;j++)
    {


        __m256i SS1 =
            ROTL256(

                _mm256_add_epi32(

                    _mm256_add_epi32(

                        ROTL256(
                            A,
                            12
                        ),

                        E

                    ),


                    ROTL256(
                        T256(j),
                        j%32
                    )

                ),

                7

            );




        __m256i SS2 =
            _mm256_xor_si256(

                SS1,

                ROTL256(
                    A,
                    12
                )

            );




        __m256i TT1 =
            _mm256_add_epi32(

                _mm256_add_epi32(

                    _mm256_add_epi32(

                        FF256(
                            A,
                            B,
                            C,
                            j
                        ),

                        D

                    ),

                    SS2

                ),

                _mm256_xor_si256(

                    W[j],

                    W[j+4]

                )

            );





        __m256i TT2 =
            _mm256_add_epi32(

                _mm256_add_epi32(

                    _mm256_add_epi32(

                        GG256(
                            E,
                            F,
                            G,
                            j
                        ),

                        H

                    ),

                    SS1

                ),

                W[j]

            );





        D=C;

        C=ROTL256(
            B,
            9
        );

        B=A;

        A=TT1;



        H=G;

        G=ROTL256(
            F,
            19
        );

        F=E;

        E=P0_256(
            TT2
        );


    }



    /*
     * 与旧状态异或
     */

    state[0]=
        _mm256_xor_si256(
            state[0],
            A
        );


    state[1]=
        _mm256_xor_si256(
            state[1],
            B
        );


    state[2]=
        _mm256_xor_si256(
            state[2],
            C
        );


    state[3]=
        _mm256_xor_si256(
            state[3],
            D
        );


    state[4]=
        _mm256_xor_si256(
            state[4],
            E
        );


    state[5]=
        _mm256_xor_si256(
            state[5],
            F
        );


    state[6]=
        _mm256_xor_si256(
            state[6],
            G
        );


    state[7]=
        _mm256_xor_si256(
            state[7],
            H
        );

}

/*
 * AVX2版本SM3主函数
 *
 * 输入:
 *
 * msg[8][64]
 *
 * 8个已经padding好的消息块
 *
 *
 * 输出:
 *
 * digest[8][32]
 *
 * 8个SM3结果
 */
void sm3_avx2(
    const uint8_t msg[SM3_AVX2_LANES][64],
    uint8_t digest[SM3_AVX2_LANES][32]
)
{


    /*
     * 初始化8路状态
     *
     * 原本:
     *
     * uint32_t state[8]
     *
     *
     * 现在:
     *
     * __m256i state[8]
     *
     *
     * 每个寄存器保存8个消息的状态
     *
     */


    __m256i state[8];



    for(int i=0;i<8;i++)
    {

        state[i]=
            _mm256_set1_epi32(
                IV[i]
            );

    }




    /*
     * 消息扩展
     */

    __m256i W[68];


    expand_avx2(
        msg,
        W
    );



    /*
     * 压缩
     */

    compress_avx2(
        state,
        W
    );




    /*
     * 将8个AVX2寄存器拆出来
     *
     * state:
     *
     * |msg0|msg1|...|msg7|
     *
     *
     * 变回:
     *
     * digest[0]
     * digest[1]
     * ...
     * digest[7]
     *
     */


    uint32_t temp[8];



    for(int i=0;i<8;i++)
    {


        _mm256_storeu_si256(

            (__m256i*)temp,

            state[i]

        );



        for(int lane=0;lane<8;lane++)
        {

            uint32_t value=temp[lane];


            digest[lane][i*4]
                =
                (value>>24)&0xff;


            digest[lane][i*4+1]
                =
                (value>>16)&0xff;


            digest[lane][i*4+2]
                =
                (value>>8)&0xff;


            digest[lane][i*4+3]
                =
                value&0xff;

        }

    }


}
