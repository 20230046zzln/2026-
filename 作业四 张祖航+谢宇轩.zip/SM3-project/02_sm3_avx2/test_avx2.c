#include "sm3_avx2.h"

#include <stdio.h>
#include <string.h>



int main()
{

    /*
     * 8个消息块
     *
     * 每个64字节
     *
     * 这里直接使用已经padding好的:
     *
     * "abc"
     *
     * + 0x80
     * + 0补齐
     * + 长度64bit
     *
     */


    uint8_t msg[8][64] = {0};



    for(int i=0;i<8;i++)
    {

        /*
         * abc
         */

        msg[i][0]='a';
        msg[i][1]='b';
        msg[i][2]='c';


        /*
         * padding
         */

        msg[i][3]=0x80;



        /*
         * 原消息长度:
         *
         * 3 bytes = 24 bit
         *
         * 最后8字节保存长度
         *
         */

        msg[i][63]=0x18;

    }




    uint8_t digest[8][32]={0};



    /*
     * 调用AVX2 SM3
     */

    sm3_avx2(
        msg,
        digest
    );




    /*
     * 输出8个结果
     */

    for(int lane=0;lane<8;lane++)
    {

        printf(
            "SM3 result %d:\n",
            lane
        );


        for(int i=0;i<32;i++)
        {

            printf(
                "%02x",
                digest[lane][i]
            );

        }


        printf("\n\n");

    }



    return 0;

}
