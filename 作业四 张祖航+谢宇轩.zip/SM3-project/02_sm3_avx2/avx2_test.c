#include <stdio.h>
#include <immintrin.h>


int main()
{

    __m256i a;


    a = _mm256_set1_epi32(1);


    int x[8];


    _mm256_storeu_si256(
        (__m256i*)x,
        a
    );


    for(int i=0;i<8;i++)
    {
        printf("%d ",x[i]);
    }


    printf("\n");


    return 0;
}
