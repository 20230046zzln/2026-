#include "sm3_neon.h"

#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <time.h>


#define TEST_NUM 1000000
#define LANES 4



int main()
{

    uint8_t msg[LANES][64];

    uint8_t digest[LANES][32];


    /*
     * 构造4路测试数据
     */
    memset(
        msg,
        0,
        sizeof(msg)
    );


    for(int i=0;i<LANES;i++)
    {

        msg[i][0]='a';
        msg[i][1]='b';
        msg[i][2]='c';

        msg[i][3]=0x80;

        msg[i][63]=0x18;

    }



    struct timespec start,end;



    clock_gettime(
        CLOCK_MONOTONIC,
        &start
    );



    for(int i=0;i<TEST_NUM;i++)
    {

        sm3_neon(
            msg,
            digest
        );

    }



    clock_gettime(
        CLOCK_MONOTONIC,
        &end
    );



    double time_used =
        (end.tv_sec-start.tv_sec)
        +
        (end.tv_nsec-start.tv_nsec)
        /
        1000000000.0;



    /*
     * NEON一次处理4个64字节block
     */
    double data_MB =
        (double)64
        *
        LANES
        *
        TEST_NUM
        /
        1024
        /
        1024;



    printf(
        "NEON SM3 block:\n"
    );


    printf(
        "time = %.6f s\n",
        time_used
    );


    printf(
        "data = %.2f MB\n",
        data_MB
    );


    printf(
        "speed = %.2f MB/s\n",
        data_MB/time_used
    );


    return 0;

}
