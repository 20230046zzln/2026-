#include "sm3_neon.h"

#include <stdio.h>
#include <string.h>



void print_hex(
    uint8_t digest[32]
)
{

    for(int i=0;i<32;i++)
    {
        printf(
            "%02x",
            digest[i]
        );
    }

    printf("\n");

}





int main()
{


    printf("SM3 NEON test start\n");



    /*
     * 4路输入
     *
     * 每一路都是 SM3("abc")
     *
     */


    uint8_t msg[SM3_NEON_LANES][64];



    memset(
        msg,
        0,
        sizeof(msg)
    );



    for(int i=0;i<SM3_NEON_LANES;i++)
    {

        /*
         * abc
         */
        msg[i][0]='a';
        msg[i][1]='b';
        msg[i][2]='c';


        /*
         * SM3 padding:
         *
         * 10000000
         */
        msg[i][3]=0x80;


        /*
         * 长度:
         *
         * 3 bytes = 24 bits
         *
         * 最后8字节保存bit长度
         *
         */
        msg[i][63]=0x18;

    }





    uint8_t digest[SM3_NEON_LANES][32];



    sm3_neon(
        msg,
        digest
    );





    for(int i=0;i<SM3_NEON_LANES;i++)
    {

        printf(
            "\nSM3 result %d:\n",
            i
        );


        print_hex(
            digest[i]
        );

    }



    return 0;

}
