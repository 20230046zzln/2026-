#ifndef SM3_NEON_H
#define SM3_NEON_H


#include <stdint.h>
#include <arm_neon.h>


/*
 * ARM64 NEON:
 *
 * 128 bit寄存器
 *
 * 一个元素:
 * uint32_t = 32 bit
 *
 * 128 / 32 = 4
 *
 * 所以一次并行4路SM3
 */
#define SM3_NEON_LANES 4



/*
 * ARM64 NEON版本SM3接口
 *
 * 输入:
 *
 * msg[4][64]
 *
 * 4个已经padding好的512bit消息块
 *
 *
 * 输出:
 *
 * digest[4][32]
 *
 * 4个256bit哈希结果
 *
 */
void sm3_neon(
    const uint8_t msg[SM3_NEON_LANES][64],
    uint8_t digest[SM3_NEON_LANES][32]
);


#endif
