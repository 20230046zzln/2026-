#include "sm3_neon.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>



/*
 * SM3初始向量
 */
static const uint32_t IV[8] =
{
    0x7380166f,
    0x4914b2b9,
    0x172442d7,
    0xda8a0600,
    0xa96f30bc,
    0x163138aa,
    0xe38dee4d,
    0xb0fb0e4e
};





/*
 * NEON版本循环左移
 *
 * x:
 *
 * |x0|x1|x2|x3|
 *
 * 四路32bit同时旋转
 *
 *
 * vshlq_n_u32:
 * 左移
 *
 * vshrq_n_u32:
 * 右移
 *
 * vorrq_u32:
 * 或
 *
 */
static uint32x4_t ROTL_NEON(
    uint32x4_t x,
    int n
)
{

    return vorrq_u32(

        vshlq_n_u32(
            x,
            n
        ),

        vshrq_n_u32(
            x,
            32-n
        )

    );

}






/*
 * P0函数
 *
 * P0(X)=X^ROTL(X,9)^ROTL(X,17)
 */
static uint32x4_t P0_NEON(
    uint32x4_t x
)
{

    return veorq_u32(

        x,

        veorq_u32(

            ROTL_NEON(
                x,
                9
            ),

            ROTL_NEON(
                x,
                17
            )

        )

    );

}






/*
 * P1函数
 *
 * P1(X)=X^ROTL(X,15)^ROTL(X,23)
 */
static uint32x4_t P1_NEON(
    uint32x4_t x
)
{

    return veorq_u32(

        x,

        veorq_u32(

            ROTL_NEON(
                x,
                15
            ),

            ROTL_NEON(
                x,
                23
            )

        )

    );

}






/*
 * FF函数 NEON版本
 *
 *
 * 前16轮:
 *
 * X ^ Y ^ Z
 *
 *
 * 后48轮:
 *
 * (X&Y)|(X&Z)|(Y&Z)
 */
static uint32x4_t FF_NEON(
    uint32x4_t x,
    uint32x4_t y,
    uint32x4_t z,
    int j
)
{

    if(j < 16)
    {

        return veorq_u32(

            veorq_u32(
                x,
                y
            ),

            z

        );

    }
    else
    {

        return vorrq_u32(

            vorrq_u32(

                vandq_u32(
                    x,
                    y
                ),

                vandq_u32(
                    x,
                    z
                )

            ),

            vandq_u32(
                y,
                z
            )

        );

    }

}







/*
 * GG函数 NEON版本
 *
 *
 * 前16轮:
 *
 * X^Y^Z
 *
 *
 * 后48轮:
 *
 * (X&Y)|(~X&Z)
 *
 */
static uint32x4_t GG_NEON(
    uint32x4_t x,
    uint32x4_t y,
    uint32x4_t z,
    int j
)
{

    if(j < 16)
    {

        return veorq_u32(

            veorq_u32(
                x,
                y
            ),

            z

        );

    }
    else
    {

        return vorrq_u32(

            vandq_u32(
                x,
                y
            ),

            vbicq_u32(
                z,
                x
            )

        );

    }

}






/*
 * SM3轮常量
 *
 * 广播到4个lane
 */
static uint32x4_t T_NEON(
    int j
)
{

    uint32_t t;


    if(j < 16)
    {
        t = 0x79cc4519;
    }
    else
    {
        t = 0x7a879d8a;
    }



    return vdupq_n_u32(
        t
    );

}
/*
 * NEON消息扩展
 *
 * 输入:
 *
 * block[4][64]
 *
 * 4个512bit消息块
 *
 *
 * 输出:
 *
 * W[68]
 *
 * 每个uint32x4_t:
 *
 * |msg0|msg1|msg2|msg3|
 *
 */
static void expand_neon(
    const uint8_t block[4][64],
    uint32x4_t W[68]
)
{

    uint32_t temp[4];



    /*
     * W0~W15
     *
     * 读取消息
     *
     * SM3使用大端
     */
    for(int j=0;j<16;j++)
    {


        for(int lane=0;lane<4;lane++)
        {

            temp[lane] =
                ((uint32_t)block[lane][j*4] << 24)
                |
                ((uint32_t)block[lane][j*4+1] << 16)
                |
                ((uint32_t)block[lane][j*4+2] << 8)
                |
                ((uint32_t)block[lane][j*4+3]);

        }



        /*
         * NEON lane顺序:
         *
         * lane0 lane1 lane2 lane3
         *
         */
        W[j]=vsetq_lane_u32(
                temp[0],
                W[j],
                0
        );

        W[j]=vsetq_lane_u32(
                temp[1],
                W[j],
                1
        );

        W[j]=vsetq_lane_u32(
                temp[2],
                W[j],
                2
        );

        W[j]=vsetq_lane_u32(
                temp[3],
                W[j],
                3
        );


    }




    /*
     * W16~W67
     *
     *
     * Wj =
     *
     * P1(
     * Wj-16 ^ Wj-9 ^ ROTL(Wj-3,15)
     * )
     *
     * ^
     *
     * ROTL(Wj-13,7)
     *
     * ^
     *
     * Wj-6
     *
     */
    for(int j=16;j<68;j++)
    {


        uint32x4_t x =
            veorq_u32(

                veorq_u32(

                    W[j-16],

                    W[j-9]

                ),

                ROTL_NEON(
                    W[j-3],
                    15
                )

            );



        W[j]=
            veorq_u32(

                veorq_u32(

                    P1_NEON(x),

                    ROTL_NEON(
                        W[j-13],
                        7
                    )

                ),

                W[j-6]

            );


    }

}







/*
 * NEON SM3压缩函数
 *
 * 一次处理4个消息
 *
 */
static void compress_neon(
    uint32x4_t state[8],
    uint32x4_t W[68]
)
{


    uint32x4_t A=state[0];
    uint32x4_t B=state[1];
    uint32x4_t C=state[2];
    uint32x4_t D=state[3];

    uint32x4_t E=state[4];
    uint32x4_t F=state[5];
    uint32x4_t G=state[6];
    uint32x4_t H=state[7];




    for(int j=0;j<64;j++)
    {


        uint32x4_t SS1 =
            ROTL_NEON(

                vaddq_u32(

                    vaddq_u32(

                        ROTL_NEON(
                            A,
                            12
                        ),

                        E

                    ),

                    ROTL_NEON(
                        T_NEON(j),
                        j%32
                    )

                ),

                7

            );




        uint32x4_t SS2 =
            veorq_u32(

                SS1,

                ROTL_NEON(
                    A,
                    12
                )

            );





        uint32x4_t TT1 =
            vaddq_u32(

                vaddq_u32(

                    vaddq_u32(

                        FF_NEON(
                            A,
                            B,
                            C,
                            j
                        ),

                        D

                    ),

                    SS2

                ),

                veorq_u32(

                    W[j],

                    W[j+4]

                )

            );






        uint32x4_t TT2 =
            vaddq_u32(

                vaddq_u32(

                    vaddq_u32(

                        GG_NEON(
                            E,
                            F,
                            G,
                            j
                        ),

                        H

                    ),

                    SS1

                ),

                W[j]

            );






        D=C;

        C=ROTL_NEON(
            B,
            9
        );

        B=A;

        A=TT1;




        H=G;

        G=ROTL_NEON(
            F,
            19
        );

        F=E;

        E=P0_NEON(
            TT2
        );


    }





    /*
     * 更新状态
     */
    state[0]=
        veorq_u32(
            state[0],
            A
        );


    state[1]=
        veorq_u32(
            state[1],
            B
        );


    state[2]=
        veorq_u32(
            state[2],
            C
        );


    state[3]=
        veorq_u32(
            state[3],
            D
        );


    state[4]=
        veorq_u32(
            state[4],
            E
        );


    state[5]=
        veorq_u32(
            state[5],
            F
        );


    state[6]=
        veorq_u32(
            state[6],
            G
        );


    state[7]=
        veorq_u32(
            state[7],
            H
        );


}
/*
 * NEON版本SM3主函数
 *
 * 输入:
 *
 * msg[4][64]
 *
 * 4个已经padding好的消息块
 *
 *
 * 输出:
 *
 * digest[4][32]
 *
 * 4个SM3结果
 *
 */
void sm3_neon(
    const uint8_t msg[SM3_NEON_LANES][64],
    uint8_t digest[SM3_NEON_LANES][32]
)
{


    /*
     * 初始化状态
     *
     * 每个NEON寄存器保存4路状态
     *
     *
     * state[0]:
     *
     * IV0 IV0 IV0 IV0
     *
     */

    uint32x4_t state[8];



    for(int i=0;i<8;i++)
    {

        state[i]=vdupq_n_u32(
            IV[i]
        );

    }




    /*
     * 消息扩展
     */

    uint32x4_t W[68];


    expand_neon(
        msg,
        W
    );



    /*
     * 64轮压缩
     */

    compress_neon(
        state,
        W
    );




    /*
     * 将NEON寄存器拆成4路digest
     *
     *
     * state[i]:
     *
     * |msg0|msg1|msg2|msg3|
     *
     *
     * 转换:
     *
     * digest[0]
     * digest[1]
     * digest[2]
     * digest[3]
     *
     */


    uint32_t temp[4];



    for(int i=0;i<8;i++)
    {


        vst1q_u32(
            temp,
            state[i]
        );



        for(int lane=0;lane<4;lane++)
        {

            uint32_t value=temp[lane];


            digest[lane][i*4]
                =
                (value>>24)&0xff;


            digest[lane][i*4+1]
                =
                (value>>16)&0xff;


            digest[lane][i*4+2]
                =
                (value>>8)&0xff;


            digest[lane][i*4+3]
                =
                value&0xff;

        }

    }


}
